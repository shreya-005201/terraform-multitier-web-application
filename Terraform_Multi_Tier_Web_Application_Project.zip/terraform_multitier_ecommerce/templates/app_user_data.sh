#!/bin/bash
set -euxo pipefail
dnf update -y
dnf install -y python3
mkdir -p /opt/shop-app

cat > /opt/shop-app/server.py <<'PY'
from http.server import BaseHTTPRequestHandler, HTTPServer
import json

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/healthz":
            body = b"ok"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
        else:
            body = json.dumps({
                "service": "sample-application-tier",
                "status": "running",
                "note": "Demo endpoint; connect application logic and database access here."
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

HTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
PY

cat > /etc/systemd/system/shop-app.service <<'SERVICE'
[Unit]
Description=Sample Shop Application
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/shop-app
ExecStart=/usr/bin/python3 /opt/shop-app/server.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable --now shop-app
