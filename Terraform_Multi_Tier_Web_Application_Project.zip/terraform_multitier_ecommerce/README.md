# Multi-Tier Web Application on AWS — Terraform

## 1. Overview

This Terraform project provisions a demonstration three-tier architecture in AWS:

1. **Web tier:** Public Application Load Balancer (ALB) forwards HTTP traffic to an Auto Scaling Group of Nginx web instances.
2. **Application tier:** Nginx proxies requests to an internal ALB, which routes to an Auto Scaling Group of sample Python application instances.
3. **Database tier:** Amazon RDS for PostgreSQL is deployed in isolated database subnets. Its security group permits PostgreSQL traffic only from the application tier.

The VPC spans two Availability Zones. The web and application instances are placed in private subnets; only the public ALB is internet-facing. A NAT Gateway provides outbound package access to private instances. CloudWatch CPU alarms and EC2 Auto Scaling target-tracking policies provide basic health/capacity monitoring.

**Important:** The Python application is a small demonstration endpoint. It does not implement a real store, persist orders, or connect to RDS yet. The RDS instance and secure network path are provisioned so that database integration can be added as a next development step.

## 2. Architecture

Customer → Public ALB → Nginx web Auto Scaling Group → Internal ALB → Python application Auto Scaling Group → Private RDS PostgreSQL.

Supporting resources: VPC, public/app/database subnets, Internet Gateway, NAT Gateway, route tables, security groups, EC2 IAM role/instance profile for Systems Manager, and CloudWatch alarms.

## 3. Files

- `versions.tf` — Terraform and AWS provider version constraints.
- `variables.tf` — configurable inputs.
- `main.tf` — network, security, load balancers, EC2 Auto Scaling, RDS and monitoring resources.
- `outputs.tf` — website URL, load balancer names, database endpoint and VPC ID.
- `terraform.tfvars.example` — example non-secret configuration.
- `templates/app_user_data.sh` — installs and starts the sample Python application.
- `templates/web_user_data.sh.tftpl` — installs Nginx and configures reverse proxying.
- `.gitignore` — excludes local state and secret variable files.

## 4. Prerequisites

- An AWS account with permission to create VPC, EC2, ELB, RDS, IAM, CloudWatch, NAT Gateway and Elastic IP resources.
- AWS CLI configured with credentials (`aws configure` or an approved role/SSO flow).
- Terraform CLI 1.5 or later.
- An AWS Region with at least two available Availability Zones.
- A unique resource naming prefix if deploying more than once in the same account.

Do not commit AWS credentials, database passwords, Terraform state files or `.tfvars` files containing secrets to GitHub.

## 5. Configure

From this directory, set the database password in the shell rather than placing it in source control.

Linux/macOS:
```bash
export TF_VAR_db_password='Use-A-Long-Random-Password-Here'
```

PowerShell:
```powershell
$env:TF_VAR_db_password = "Use-A-Long-Random-Password-Here"
```

Optionally copy `terraform.tfvars.example` to `terraform.tfvars` and adjust region, instance sizes and capacity. The example file intentionally contains no password.

## 6. Deploy

Run these commands from the project directory:

```bash
terraform fmt -recursive
terraform init
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
terraform output
```

Terraform displays the public ALB URL as `website_url`. Open that URL after the load balancer target group reports healthy targets. The sample application should return JSON describing the demo service.

For a basic command-line check:
```bash
curl "$(terraform output -raw website_url)"
```

The health endpoint is:
```bash
curl "$(terraform output -raw website_url)/healthz"
```

A successful `terraform validate` confirms configuration syntax and internal consistency; it does not prove that AWS deployment will succeed. A successful `terraform apply` and live endpoint test are required to demonstrate deployment.

## 7. Validate after deployment

1. In the AWS Console, confirm the VPC has two public, two application and two database subnets across two AZs.
2. Confirm the public ALB is internet-facing and the application ALB is internal.
3. Confirm web and application Auto Scaling Groups have healthy instances in both AZs.
4. Confirm the web target group and application target group show healthy targets.
5. Open the `website_url` output and confirm the sample JSON response.
6. Request `/healthz` and confirm HTTP 200.
7. Confirm RDS is not publicly accessible and its security group allows port 5432 only from the application security group.
8. Review CloudWatch alarms and Auto Scaling activity history.
9. Capture genuine screenshots of the AWS Console and terminal after successful deployment for the final submission.

## 8. Monitoring and scaling

Both Auto Scaling Groups use target tracking to maintain average EC2 CPU utilization near 60%, with minimum and maximum capacity controlled by variables. CloudWatch alarms notify through alarm state when average CPU is above 75% for two consecutive five-minute periods. To send notifications, add an SNS topic and subscribe an email or operations endpoint.

For production, add ALB request-count and target-response-time alarms, application logs, structured metrics, tracing, database CPU/storage/connection alarms and an operational dashboard. CPU is only one scaling signal; validate the policy with load testing.

## 9. Security notes

- The public ALB is the only internet-facing compute entry point in this example.
- EC2 instances have no public IP addresses and use an IAM instance profile.
- IMDSv2 is required on EC2 instances.
- The database is private, encrypted at rest and restricted to the application security group.
- Use HTTPS with AWS Certificate Manager and a domain name before production use. The sample currently exposes HTTP on port 80 to keep the exercise easy to test.
- Store secrets in AWS Secrets Manager or an approved secure secret system in production. The Terraform password variable is marked sensitive, but Terraform state can still contain the value; secure and encrypt the state backend and restrict access.
- Review IAM permissions, patching, WAF rules, logging and vulnerability management before production.

## 10. Cost and cleanup

This example creates billable resources, notably a NAT Gateway, two ALBs, EC2 instances, RDS Multi-AZ, EBS volumes, data transfer and CloudWatch metrics/logs. Charges can accrue even while idle. Check the AWS Pricing Calculator for the selected Region before deployment. Use a sandbox account and set an AWS Budget alert.

When finished, remove the infrastructure to stop ongoing charges:

```bash
terraform destroy
```

Review the destroy plan carefully. Never run destroy against a shared or production environment without authorization. If deletion protection or retained data is enabled later, follow the organization's data-retention process.

## 11. Design limitations and production improvements

- The demo app does not yet use the database; implement database connection pooling, migrations, parameterized queries and secret retrieval before using it as a real application.
- A single NAT Gateway is a cost-saving compromise and a potential Availability Zone dependency. Use one NAT Gateway per AZ for stronger production resilience.
- Add HTTPS, Route 53, CloudFront, AWS WAF, S3 for static assets, backups with tested restore, SNS notifications, centralized logging and an IaC remote state backend with locking.
- Consider an RDS Multi-AZ deployment and cross-Region recovery only after business RTO/RPO and cost are agreed.
- The configuration uses a sample Amazon Linux 2023 AMI lookup and a PostgreSQL engine version; verify current regional availability before deployment.

## 12. Post-deployment analysis template

Complete this section only after actually running the deployment:

- Terraform version:
- AWS Region:
- `terraform validate` result:
- `terraform apply` result:
- Public website URL:
- Web target group health:
- Application target group health:
- RDS status:
- `/healthz` HTTP result:
- Observed scaling/monitoring behavior:
- Errors or changes made:
- Screenshots attached:

**Do not report a successful deployment or attach fabricated terminal output.** If you cannot deploy because you do not have AWS access, state that the configuration was prepared and syntax-checked locally (only if you actually ran validation), and explain that live deployment validation remains pending.
