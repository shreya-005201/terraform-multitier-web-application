variable "aws_region" {
  description = "AWS Region for this deployment."
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Short name used to tag and name resources."
  type        = string
  default     = "internship-multitier"
}

variable "vpc_cidr" {
  description = "CIDR range for the VPC."
  type        = string
  default     = "10.20.0.0/16"
}

variable "instance_type" {
  description = "EC2 instance type for web and application tiers."
  type        = string
  default     = "t3.micro"
}

variable "web_min_size" {
  type        = number
  default     = 2
  description = "Minimum number of web instances."
}

variable "web_desired_capacity" {
  type        = number
  default     = 2
  description = "Initial desired number of web instances."
}

variable "web_max_size" {
  type        = number
  default     = 4
  description = "Maximum number of web instances."
}

variable "app_min_size" {
  type        = number
  default     = 2
  description = "Minimum number of application instances."
}

variable "app_desired_capacity" {
  type        = number
  default     = 2
  description = "Initial desired number of application instances."
}

variable "app_max_size" {
  type        = number
  default     = 4
  description = "Maximum number of application instances."
}

variable "db_name" {
  type        = string
  default     = "shopdb"
  description = "Initial PostgreSQL database name."
}

variable "db_username" {
  type        = string
  default     = "shopadmin"
  description = "Database administrator username."
}

variable "db_password" {
  type        = string
  sensitive   = true
  description = "Database password. Supply through TF_VAR_db_password or a secure secret workflow."
}

variable "db_instance_class" {
  type        = string
  default     = "db.t3.micro"
  description = "RDS instance class; confirm regional availability and Free Tier eligibility."
}

variable "db_allocated_storage" {
  type        = number
  default     = 20
  description = "Initial RDS storage in GiB."
}
