output "website_url" {
  description = "HTTP URL of the public web load balancer."
  value       = "http://${aws_lb.web.dns_name}"
}

output "web_load_balancer_dns" {
  value = aws_lb.web.dns_name
}

output "application_load_balancer_dns_internal" {
  description = "Internal-only application load balancer DNS name."
  value       = aws_lb.app.dns_name
}

output "rds_endpoint" {
  description = "Private RDS endpoint; reachable only from the application tier."
  value       = aws_db_instance.main.address
}

output "vpc_id" {
  value = aws_vpc.main.id
}
